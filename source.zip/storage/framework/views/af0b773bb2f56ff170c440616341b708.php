<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel</title>
    <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.jsx']); ?>
    <style>
        @tailwind base;
        @tailwind components;
        @tailwind utilities;
    </style>
</head>
<body>
<div class="w-full flex flex-wrap">
    <aside class="w-2/12 bg-gray-500 text-white min-h-[100svh] p-6">
        <nav>
            <ul class="flex flex-col gap-y-3">
                <li><a href="/admin-dashboard">خانه</a></li>
                <li><a href="/groups">گروه قطعی</a></li>
                <li><a href="">محل های پخش</a></li>
                <li><a href="">کاربران و مصارف</a></li>
                <li><a href="">احراز هویت</a></li>
                <li><a href="">پاسخگویی پشتیبانی</a></li>
            </ul>
        </nav>
    </aside>
    <main class="w-10/12  min-h[100svh] flex flex-col p-10 gap-x-5">
        <h1 class="text-3xl mb-8">گروه های قعطی آب</h1>
        <a class="flex justify-center items-center rounded-2xl bg-sky-300 px-8 py-5 my-6 " href="/groups">افزودن گروه جدید به لیست</a>
        <table class="mt-8 border border-collapse text-center">
            <thead>
            <tr class="bg-gray-100 ">
                <th class="w-2/12">شماره گروه </th>
                <th>محلات و مناطق های تحت پوشش</th>
                <th class="w-2/12">زمان قعطی</th>
                <th class="w-1/12">عملیات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b">

                    <td class="py-5"><?php echo e($group->title); ?></td>
                    <td class="py-5"><?php echo e($group->details); ?></td>
                    <td class="py-5"><?php echo e($group->time); ?></td>
                    <td class="py-5">
                        <form action="<?php echo e(route("group-edit",$group->id)); ?>" method="get">
                            <?php echo csrf_field(); ?>
                            <button class="bg-sky-300 text-white px-4 py-2 rounded-2xl" type="submit">ویرایش</button>
                        </form>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

    </main>
</div>
</body>
</html>
<?php /**PATH /Users/nimaaaa/Desktop/parvaz-app/resources/views/admin-dashboard/group.blade.php ENDPATH**/ ?>