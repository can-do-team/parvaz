import React, { useState } from 'react';

const Test = () => {
    return (
        <h1 className="text-3xl font-bold underline bg-blue-700">
            Hello world!sad
        </h1>
    )
}

export default Test
