<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreSupportMessageRequest;
use App\Http\Requests\UpdateSupportMessageRequest;
use App\Models\SupportMessage;

class SupportMessageController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreSupportMessageRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(SupportMessage $supportMessage)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(SupportMessage $supportMessage)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateSupportMessageRequest $request, SupportMessage $supportMessage)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(SupportMessage $supportMessage)
    {
        //
    }
}
